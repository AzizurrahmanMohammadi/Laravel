    <?php $__env->startSection('content'); ?>

<h1><?php echo e($title); ?></h1>
        <p>Now laravel 7 released and I will study laravel 7 inshaallah</p>
   <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lsapp\resources\views/pages/about.blade.php ENDPATH**/ ?>