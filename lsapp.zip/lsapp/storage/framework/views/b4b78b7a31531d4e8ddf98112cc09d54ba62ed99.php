<?php $__env->startSection('content'); ?>
      
<a href="/lsapp/public/posts" class="btn btn-default">Go Back</a>   
        <h3><?php echo e($post->title); ?></h3>
        <div>
            <?php echo e($post->body); ?>

        
        <hr>
        <small>Written on <?php echo e($post->created_at); ?></small>
   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lsapp\resources\views/posts/show.blade.php ENDPATH**/ ?>