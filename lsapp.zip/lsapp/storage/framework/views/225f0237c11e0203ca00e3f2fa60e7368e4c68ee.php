<?php $__env->startSection('content'); ?>
 <div class="jumbottron text-center">
    <h1>Welcome To Laravel 5.4!</h1>
    <p>This series is make blog post</p>
    <p><a class="btn btn-primary btn-lg" href="/login" role="button">Login</a>
                      <a class="btn btn-success btn-lg" href="/register" role="button">Register</a></p>

 </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lsapp\resources\views/pages/index.blade.php ENDPATH**/ ?>