@extends('layout.app')

    @section('content')

<h1>{{$title}}</h1>
        <p>Now laravel 7 released and I will study laravel 7 inshaallah</p>
   @endsection