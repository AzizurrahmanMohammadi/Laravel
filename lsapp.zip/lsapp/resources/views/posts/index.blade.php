@extends('layout.app')

@section('content')
    <h1>Posts</h1>
    @if (count($posts)>0)
        <div class="well">
            @foreach ($posts as $post)
        <h3><a href="/lsapp/public/posts/{{$post->id}}">{{$post->title}}</a></h3>
               <small>Written on {{$post->created_at}}</small>
               @endforeach 
               {{$posts->links()}}
        </div>
    @else
        <p>No Post Found</p>
    @endif
@endsection