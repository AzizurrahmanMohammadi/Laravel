@extends('layout.app')

@section('content')
    <h1>Create Post</h1>

      {!! Form::open(['action' => 'PostController@store', 'method' =>'POST']) !!}
        <div calss="form-group">
            {{Form::lable('title', 'Title')}}
            {{Form::text('title', '', ['class' => 'form-control', 'placeholder' => 'Title'])}}
        </div>

        <div calss="form-group">
            {{Form::lable('body', 'Body')}}
            {{Form::textarea('body', '', ['class' => 'form-control', 'placeholder' => 'Body'])}}
        </div>
        {{Form::submit('Submit', ['class'=>'btn btn-primary'])}}

      {!! Form::close() !!}
  
@endsection