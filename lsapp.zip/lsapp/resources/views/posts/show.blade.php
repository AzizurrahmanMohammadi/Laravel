@extends('layout.app')

@section('content')
      
      <a href="/lsapp/public/posts" class="btn btn-default">Go Back</a>   
        <h3>{{$post->title}}</h3>
        <div>
            {{$post->body}}
        
        <hr>
        <small>Written on {{$post->created_at}}</small>
   
@endsection