<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Post extends Model
{
    //Table Nmae 
    protected $table = 'posts';

    //Primary key
    public $primaryKey = 'id';

    //TimeStamp
    public $timestamps = true;
}
